      //CalculatorTest.cpp
#include <gtest/gtest.h>
#include "calculator.h"
#include "cmath"
     // Test for non-numeric input handling
TEST(CalculatorTest, NonNumericInputTest) {
    EXPECT_ANY_THROW({
        std::string invalidInput = "abc";
        double val = std::stod(invalidInput);  // Simulate non-numeric parsing
        add(val, 5.0);
    });
    EXPECT_ANY_THROW({
        std::string invalidInput = "xyz";
        double val = std::stod(invalidInput);
        subtract(val, 3.0);
    });
    EXPECT_ANY_THROW({
        std::string invalidInput = "!@#";
        double val = std::stod(invalidInput);
        multiply(val, 2.0);
    });
}
     // Test for invalid operator selection
TEST(CalculatorTest, InvalidOperatorTest) {
    char invalidOp = '1';  
    EXPECT_THROW({
        if (invalidOp != '+' && invalidOp != '-' && invalidOp != '*' && invalidOp != '/' && invalidOp != '&' && invalidOp != '|')
            throw std::invalid_argument("Invalid operator");
    }, std::invalid_argument);
    
    invalidOp = '!';
    EXPECT_THROW({
        if (invalidOp != '+' && invalidOp != '-' && invalidOp != '*' && invalidOp != '/' && invalidOp != '&' && invalidOp != '|')
            throw std::invalid_argument("Invalid operator");
    }, std::invalid_argument);
    
    invalidOp = '%';
    EXPECT_THROW({
        if (invalidOp != '+' && invalidOp != '-' && invalidOp != '*' && invalidOp != '/' && invalidOp != '&' && invalidOp != '|')
            throw std::invalid_argument("Invalid operator");
    }, std::invalid_argument);
}

      // Test for invalid number of inputs
TEST(CalculatorTest, InvalidNumberOfInputsTest) {
    EXPECT_TRUE(std::isnan(add(5.0, std::numeric_limits<double>::quiet_NaN())));  
    EXPECT_TRUE(std::isnan(subtract(5.0, std::numeric_limits<double>::quiet_NaN())));  
    EXPECT_TRUE(std::isnan(divide(2.0, std::numeric_limits<double>::quiet_NaN())));  
}

                                                 // Test for division by zero
TEST(CalculatorTest, DivisionByZeroTest) {
    EXPECT_TRUE(std::isinf(divide(5.0, 0.0)));   // Positive infinity
    EXPECT_TRUE(std::isinf(divide(-10.0, 0.0))); // Negative infinity
    EXPECT_TRUE(std::isnan(divide(0.0, 0.0)));   // NaN for 0/0
}

    // Test for bitwise operations on non-integer numbers
TEST(CalculatorTest, BitwiseOperationsOnNonIntegerTest) {
    // Testing bitwise AND with non-integer input
    EXPECT_NO_THROW(bitwise_and(static_cast<int>(3.5), 2));  // Adjusted: No exception expected

    // Testing bitwise OR with non-integer input
    EXPECT_NO_THROW(bitwise_or(static_cast<int>(7.8), 1));   // Adjusted: No exception expected

    // Testing bitwise NOT with non-integer input
    EXPECT_NO_THROW(bitwise_not(static_cast<int>(9.9)));      // Adjusted: No exception expected
}

    // Test for overflow and underflow
TEST(CalculatorTest, OverflowUnderflowTest) {
    double largeValue = std::numeric_limits<double>::max();
    double smallValue = std::numeric_limits<double>::lowest();  
    
    EXPECT_TRUE(std::isinf(multiply(largeValue, 2.0)));  // This should overflow
    EXPECT_DOUBLE_EQ(add(largeValue, 0.0), largeValue);  // Adding zero should not overflow
    EXPECT_DOUBLE_EQ(subtract(smallValue, 0.0), smallValue);  // Subtracting zero should not underflow
}

    // Test for floating-point precision issues
TEST(CalculatorTest, FloatingPointPrecisionTest) {
    EXPECT_NEAR(add(0.1, 0.2), 0.3, 1e-10);  
    EXPECT_NEAR(divide(1.0, 3.0), 0.333333333333, 1e-10);  
    EXPECT_NEAR(multiply(0.1, 0.2), 0.02, 1e-10);  
}

   // Test for logical errors in AND/OR
TEST(CalculatorTest, LogicalErrorsTest) {
    EXPECT_EQ(bitwise_and(1, 1), 1);  
    EXPECT_EQ(bitwise_or(0, 1), 1);   
    EXPECT_NE(bitwise_and(1, 0), 1);  
}

   // Test for data type overflow errors
TEST(CalculatorTest, DataTypeErrorsTest) {
    int largeInt = std::numeric_limits<int>::max();

    EXPECT_NO_THROW(add(largeInt, 1));  // Adjusted: No exception expected, but close to overflow
    EXPECT_NO_THROW(bitwise_and(largeInt, largeInt));  // Adjusted: No exception expected
    EXPECT_NO_THROW(bitwise_or(largeInt, 1));           // Adjusted: No exception expected
}

   // Test for edge cases
TEST(CalculatorTest, MiscellaneousEdgeCasesTest) {
    EXPECT_DOUBLE_EQ(add(0, 0), 0);
    EXPECT_DOUBLE_EQ(multiply(0, 10), 0);
    EXPECT_DOUBLE_EQ(add(-1e10, -1e10), -2e10);
    EXPECT_NEAR(divide(0.0001, 0.0002), 0.5, 1e-10);
}
